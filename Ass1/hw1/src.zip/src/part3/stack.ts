import { State, bind } from "./state";

export type Stack = number[];

export const push = undefined;

export const pop = undefined;

export const stackManip = undefined;